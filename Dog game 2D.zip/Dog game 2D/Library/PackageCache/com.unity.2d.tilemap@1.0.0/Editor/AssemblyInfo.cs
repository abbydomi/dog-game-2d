using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.2D.Tilemap.EditorTests")]
[assembly: InternalsVisibleTo("Unity.2D.Tilemap.Package.EditorTests")]
